package com.calc;

import org.antlr.v4.runtime.ANTLRFileStream;
import org.antlr.v4.runtime.CommonTokenStream;

import com.calc.dsl.CalcLexer;
import com.calc.dsl.CalcParser;

public class Calc {
	public static void main(String[] args) {
		try {
			/** leitura do codigo-fonte */
			ANTLRFileStream input = new ANTLRFileStream("calc.plp");

			/** leitura das regras l�xicas */
			CalcLexer lexer = new CalcLexer(input);

			/** Cria lista de tokens geradas a partir do lexer */
			CommonTokenStream tokens = 
					new CommonTokenStream(lexer);

			/** leitura das regras de parser */
			CalcParser parser = new CalcParser(tokens);

			if (parser.getNumberOfSyntaxErrors() > 0) {
				System.out.println("Houve erro de sint�xe.");
			}else {
				parser.calc();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
